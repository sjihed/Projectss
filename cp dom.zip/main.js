var btnP = document.getElementsByClassName ('increment-btn');
var btnM = document.getElementsByClassName('decrement-btn');
var counter = document.getElementsByClassName('counter');
let quantity = document.getElementsByClassName ('counter');
let price = document.getElementsByClassName ('price');
let total= document.getElementById ('total-price');

for (let ele of btnP){
    ele.addEventListener('click',function inc() {
        ele.previousElementSibling.innertext ++;
    })
    totalprice();
}
for (let mines of btnM ){
    mines.addEventListener('click',function dec(){
        if (mines.nextElementSibling.innertext >0){
            mines.nextElementSibling.innertext--;
        }
    })
    totalprice();
}



function totalprice() {
    let sum = 0;
    for (let i=0; i< price.length; i++ ){
        sum += price[i].innertext * quantity [i].innertext;
        document.getElementById('total-price').innertext = sum ;
    }


}